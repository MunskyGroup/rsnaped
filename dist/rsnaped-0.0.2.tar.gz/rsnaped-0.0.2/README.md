# rSNAPed
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

rSNAPed a Python library for single-molecule image processing.

Author Luis U. Aguilera

## Description

The code is intended to automatically track single-molecules from single-cell videos. The code calculates spot position and extract intensity values.
